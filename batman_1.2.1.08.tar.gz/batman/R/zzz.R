.onLoad<-function(libname, pkgname){library.dynam("batman", pkgname,libname)}
